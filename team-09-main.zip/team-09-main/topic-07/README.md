# Subtaks for topic 07. Database Design

The project we have chosen is a travel agency database

A visual diagram of the tables of the future database has been added to the project

Also added DBML that describes the current diagram in code
