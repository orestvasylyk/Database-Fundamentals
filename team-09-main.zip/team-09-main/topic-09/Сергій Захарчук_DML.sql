INSERT INTO clients (first_name, last_name, email, phone_number) VALUES
('John', 'Doe', 'john.doe@example.com', '+1234567890'),
('Jane', 'Smith', 'jane.smith@example.com', '+1234567891'),
('Michael', 'Johnson', 'michael.johnson@example.com', '+1234567892'),
('Emily', 'Davis', 'emily.davis@example.com', '+1234567893'),
('Chris', 'Garcia', 'chris.garcia@example.com', '+1234567894'),
('Jessica', 'Martinez', 'jessica.martinez@example.com', '+1234567895'),
('Matthew', 'Rodriguez', 'matthew.rodriguez@example.com', '+1234567896'),
('Sophia', 'Wilson', 'sophia.wilson@example.com', '+1234567897'),
('Daniel', 'Anderson', 'daniel.anderson@example.com', '+1234567898'),
('Olivia', 'Thomas', 'olivia.thomas@example.com', '+1234567899');

-- Оновлення запису в таблиці clients:
UPDATE clients
SET email = 'john.new@example.com'
WHERE first_name = 'John' AND last_name = 'Doe';

-- Видалення запису з таблиці clients:
DELETE FROM clients
WHERE first_name = 'Olivia' AND last_name = 'Thomas';

