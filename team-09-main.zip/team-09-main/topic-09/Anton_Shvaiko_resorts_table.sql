-- Insert resorts into the resorts table
INSERT INTO resorts (name, type, quality, location, price_range)
VALUES 
    ('Alpine Heights', 'Mountain-Ski', 5, 'Zermatt, Switzerland', 2000.00),
    ('Seaside Paradise', 'Sea', 4, 'Santorini, Greece', 1500.00),
    ('Jungle Retreat', 'Rainforest', 5, 'Amazon, Brazil', 1800.00),
    ('Desert Oasis', 'Desert', 3, 'Sahara, Morocco', 1000.00),
    ('Caribbean Cove', 'Beach', 4, 'Nassau, Bahamas', 1700.00),
    ('Snowy Peaks Resort', 'Mountain-Ski', 4, 'Whistler, Canada', 1600.00),
    ('Tropical Haven', 'Island', 5, 'Male, Maldives', 2500.00),
    ('Cultural Excursion', 'Historical', 4, 'Rome, Italy', 1400.00),
    ('Safari Adventure', 'Wildlife', 5, 'Maasai Mara, Kenya', 2100.00),
    ('Winter Wonderland', 'Mountain-Ski', 4, 'Innsbruck, Austria', 1900.00);

-- Insert new resort in Japan
INSERT INTO resorts (name, type, quality, location, price_range)
    ('Mount Fuji Resort', 'Mountain-Ski', 5, 'Hakone, Japan', 2200.00);

-- Update price
UPDATE resorts
SET price_range = 1999.00
WHERE name = 'Mount Fuji Resort';

-- Fix resort type
UPDATE resorts
SET type = 'Sea'
WHERE type IN ('Beach', 'Island');

UPDATE resorts
SET type = 'Natural'
WHERE type IN ('Wildlife', 'Desert', 'Rainforest');
