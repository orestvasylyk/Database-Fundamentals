CREATE TABLE resorts (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  type VARCHAR(50) NOT NULL,
  quality INTEGER,
  location VARCHAR(100),
  price_range DECIMAL (10, 2)
);



